package com.offline_upi.offline_upi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfflineUpiApplicationTests {

	@Test
	void contextLoads() {
	}

}
