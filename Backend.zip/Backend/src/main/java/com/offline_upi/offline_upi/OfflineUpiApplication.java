package com.offline_upi.offline_upi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OfflineUpiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OfflineUpiApplication.class, args);
	}

}
