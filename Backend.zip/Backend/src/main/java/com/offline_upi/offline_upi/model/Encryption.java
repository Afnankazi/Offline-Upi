package com.offline_upi.offline_upi.model;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class Encryption {
   
    private String e;
}
