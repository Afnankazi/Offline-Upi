
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Bell, Home, Wallet, BarChart2, UserRound, ChevronDown, SendIcon, CreditCard, Clock, History, Globe } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const Dashboard = () => {
  const navigate = useNavigate();
  const userName = "Afnan"; // This would come from authentication in a real app
  const balance = "15,000";
  const [language, setLanguage] = useState('en');

  const recentContacts = [
    { id: 1, name: "Lisa", avatar: "/lovable-uploads/930842cd-268b-4300-8a42-355280d45f82.png" },
    { id: 2, name: "Sarah", avatar: "/lovable-uploads/930842cd-268b-4300-8a42-355280d45f82.png" },
    { id: 3, name: "Arjun", avatar: "/lovable-uploads/930842cd-268b-4300-8a42-355280d45f82.png" },
    { id: 4, name: "Shaunak", avatar: "/lovable-uploads/930842cd-268b-4300-8a42-355280d45f82.png" },
  ];

  // Handler for the wallet button to navigate to QR scanner
  const handleWalletClick = () => {
    navigate('/scan-qr');
  };
  
  // Handler for the report (history) button
  const handleHistoryClick = () => {
    navigate('/history');
  };

  // Handler for transfer button to navigate to UPI transfer
  const handleTransferClick = () => {
    navigate('/upi-transfer');
  };

  // Handler for the profile button
  const handleProfileClick = () => {
    navigate('/profile');
  };
  
  // Handler for my QR code button
  const handleMyQRCodeClick = () => {
    navigate('/my-qr-code');
  };

  // Handler for language change
  const handleLanguageChange = (value: string) => {
    setLanguage(value);
    // In a real app, you would update the app's language context/state here
  };

  // Text content based on selected language
  const text = {
    en: {
      hello: "Hello",
      availableBalance: "Your available balance",
      transfer: "Transfer",
      topUp: "Top Up",
      history: "History",
      recentPayments: "Recent Payments",
      financeBlogs: "Finance Blogs",
      ladkiBahinTitle: "Ladki bahin yojana",
      ladkiBahinDesc: "Get 2700 for Ladki bahin transfer by Government",
      specialGuide: "Special Guide",
      savingTips: "10 tips to save more from your monthly income",
      home: "Home",
      report: "Report",
      notify: "Notify",
      profile: "Profile",
      pickOption: "Pick an option",
    },
    hi: {
      hello: "नमस्ते",
      availableBalance: "आपका उपलब्ध शेष",
      transfer: "स्थानांतरण",
      topUp: "टॉप अप",
      history: "इतिहास",
      recentPayments: "हाल के भुगतान",
      financeBlogs: "वित्त ब्लॉग",
      ladkiBahinTitle: "लड़की बहिन योजना",
      ladkiBahinDesc: "सरकार द्वारा लड़की बहिन हस्तांतरण के लिए 2700 प्राप्त करें",
      specialGuide: "विशेष गाइड",
      savingTips: "अपनी मासिक आय से अधिक बचाने के लिए 10 टिप्स",
      home: "होम",
      report: "रिपोर्ट",
      notify: "सूचना",
      profile: "प्रोफाइल",
      pickOption: "विकल्प चुनें",
    }
  };

  const t = language === 'en' ? text.en : text.hi;

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Top Nav */}
      <header className="px-4 py-3 flex justify-between items-center bg-white border-b">
        <div className="flex items-center">
          <div 
            className="w-10 h-10 bg-seva-green rounded-full flex items-center justify-center cursor-pointer"
            onClick={handleMyQRCodeClick}
          >
            <Wallet className="w-5 h-5 text-white" />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Select value={language} onValueChange={handleLanguageChange}>
            <SelectTrigger className="w-[100px] h-8 text-xs">
              <div className="flex items-center gap-1">
                <Globe className="h-3 w-3" />
                <SelectValue>{language === 'en' ? 'English' : 'हिंदी'}</SelectValue>
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="hi">हिंदी</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4">
        {/* Balance Section */}
        <section className="mb-6">
          <h2 className="text-lg font-medium">{t.hello} {userName},</h2>
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">{t.availableBalance}</p>
            <p className="text-2xl font-bold">{balance}</p>
          </div>
        </section>

        {/* Quick Actions */}
        <section className="mb-6">
          <div className="bg-white rounded-lg shadow-sm grid grid-cols-3 divide-x">
            <Button 
              variant="ghost" 
              className="flex flex-col items-center py-4 rounded-l-lg"
              onClick={handleTransferClick}
            >
              <SendIcon className="h-5 w-5 text-seva-green mb-1" />
              <span className="text-xs">{t.transfer}</span>
            </Button>
            <Button variant="ghost" className="flex flex-col items-center py-4">
              <CreditCard className="h-5 w-5 text-seva-green mb-1" />
              <span className="text-xs">{t.topUp}</span>
            </Button>
            <Button 
              variant="ghost" 
              className="flex flex-col items-center py-4 rounded-r-lg"
              onClick={handleHistoryClick}
            >
              <History className="h-5 w-5 text-seva-green mb-1" />
              <span className="text-xs">{t.history}</span>
            </Button>
          </div>
        </section>

        {/* Recent Payments */}
        <section className="mb-6">
          <h2 className="text-base font-medium mb-3">{t.recentPayments}</h2>
          <div className="flex space-x-4 overflow-x-auto pb-2">
            {recentContacts.map((contact) => (
              <div key={contact.id} className="flex flex-col items-center">
                <Avatar className="h-12 w-12 mb-1">
                  <AvatarImage src={contact.avatar} alt={contact.name} />
                  <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <p className="text-xs">{contact.name}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Finance Blogs */}
        <section className="mb-6">
          <h2 className="text-base font-medium mb-3">{t.financeBlogs}</h2>
          <div className="space-y-3">
            <div className="bg-teal-800 text-white p-4 rounded-lg flex justify-between items-center">
              <div className="space-y-1 max-w-[60%]">
                <h3 className="font-medium text-sm">{t.ladkiBahinTitle}</h3>
                <p className="text-xs">{t.ladkiBahinDesc}</p>
              </div>
              <div className="w-16 h-16 bg-teal-600 rounded-full"></div>
            </div>
            <div className="bg-orange-100 text-orange-800 p-4 rounded-lg">
              <h3 className="font-medium text-sm">{t.specialGuide}</h3>
              <p className="text-xs">{t.savingTips}</p>
            </div>
          </div>
        </section>
      </main>

      {/* Bottom Nav */}
      <footer className="bg-white border-t py-2 px-4">
        <div className="flex justify-between items-center">
          <button className="flex flex-col items-center">
            <Home className="h-5 w-5 text-seva-green" />
            <span className="text-xs">{t.home}</span>
          </button>
          <button 
            className="flex flex-col items-center"
            onClick={handleHistoryClick}
          >
            <BarChart2 className="h-5 w-5 text-gray-400" />
            <span className="text-xs text-gray-400">{t.report}</span>
          </button>
          <div className="flex items-center justify-center">
            <div 
              className="w-10 h-10 bg-seva-gold rounded-full flex items-center justify-center text-white cursor-pointer"
              onClick={handleWalletClick}
            >
              <Wallet className="h-6 w-6" />
            </div>
          </div>
          <button className="flex flex-col items-center">
            <Bell className="h-5 w-5 text-gray-400" />
            <span className="text-xs text-gray-400">{t.notify}</span>
          </button>
          <button 
            className="flex flex-col items-center"
            onClick={handleProfileClick}
          >
            <UserRound className="h-5 w-5 text-gray-400" />
            <span className="text-xs text-gray-400">{t.profile}</span>
          </button>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;
