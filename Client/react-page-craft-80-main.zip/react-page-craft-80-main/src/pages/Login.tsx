
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/components/ui/use-toast";
import { Eye, EyeOff } from 'lucide-react';
import Logo from '@/components/Logo';

const Login = () => {
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, we would verify the PIN against a secure database
    // For demo purposes, we'll check against localStorage (NOT secure for real apps)
    const storedPin = localStorage.getItem('userPin');
    
    if (storedPin && pin === storedPin) {
      toast({
        title: "Login Successful",
        description: `Logged in as ${email}`,
      });
      
      // Navigate to dashboard after login
      navigate('/dashboard');
    } else {
      toast({
        title: "Login Failed",
        description: "Invalid email or PIN",
        variant: "destructive"
      });
    }
  };

  const handleSignUp = () => {
    navigate('/register');
  };

  const togglePinVisibility = () => {
    setShowPin(!showPin);
  };

  return (
    <div className="min-h-screen bg-seva-green p-4">
      <div className="max-w-md mx-auto pt-10">
        <div className="bg-white rounded-lg p-6">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-800">Sign in to your Account</h1>
            <div className="flex items-center mt-2">
              <p className="text-sm text-gray-600">Don't have an account?</p>
              <button 
                onClick={handleSignUp}
                className="text-sm text-blue-600 ml-1 hover:underline"
              >
                Sign Up
              </button>
            </div>
          </div>

          {/* Login Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="example@email.com"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="pin">PIN</Label>
              <div className="relative">
                <Input 
                  id="pin"
                  type={showPin ? "text" : "password"}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="Enter 6-digit PIN"
                  maxLength={6}
                  inputMode="numeric"
                  pattern="[0-9]*"
                  required
                />
                <button 
                  type="button"
                  onClick={togglePinVisibility}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2"
                >
                  {showPin ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="rememberMe" 
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                />
                <Label 
                  htmlFor="rememberMe" 
                  className="text-sm cursor-pointer"
                >
                  Remember me
                </Label>
              </div>
              
              <button 
                type="button"
                className="text-sm text-blue-600 hover:underline"
              >
                Forgot PIN?
              </button>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-seva-green hover:bg-seva-green/90 text-white font-medium"
            >
              Log In
            </Button>

            <div className="relative flex items-center justify-center mt-4">
              <hr className="w-full border-gray-300" />
              <span className="px-2 bg-white text-gray-500 text-sm">Or sign in with</span>
              <hr className="w-full border-gray-300" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Button 
                type="button" 
                variant="outline" 
                className="flex items-center justify-center space-x-2"
              >
                <img src="/lovable-uploads/6dde7e3d-65f3-4a2b-807b-c3b472d50b32.png" alt="Google" className="w-5 h-5" />
                <span>Google</span>
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                className="flex items-center justify-center space-x-2"
              >
                <img src="/lovable-uploads/6dde7e3d-65f3-4a2b-807b-c3b472d50b32.png" alt="Facebook" className="w-5 h-5" />
                <span>Facebook</span>
              </Button>
            </div>
          </form>

          {/* Terms */}
          <p className="text-xs text-gray-500 mt-6 text-center">
            By signing up, you agree to the <span className="text-blue-600">Terms of Service</span> and <span className="text-blue-600">Data Processing Agreement</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
