import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Send } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import PinConfirmation from '@/components/PinConfirmation';

const UpiTransfer = () => {
  const navigate = useNavigate();
  const [upiId, setUpiId] = useState('');
  const [amount, setAmount] = useState('');
  const [currentStep, setCurrentStep] = useState('upi-input'); // 'upi-input', 'amount-input', 'pin-confirmation'
  
  const handleBack = () => {
    if (currentStep === 'amount-input') {
      setCurrentStep('upi-input');
    } else if (currentStep === 'pin-confirmation') {
      setCurrentStep('amount-input');
    } else {
      navigate(-1);
    }
  };

  const handleContinue = () => {
    if (currentStep === 'upi-input' && upiId.trim()) {
      setCurrentStep('amount-input');
    } else if (currentStep === 'amount-input' && amount.trim()) {
      setCurrentStep('pin-confirmation');
    }
  };

  const handlePinCancel = () => {
    setCurrentStep('amount-input');
  };

  const handlePinConfirm = () => {
    // In a real app, this would process the UPI transfer
    navigate('/dashboard');
  };

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Only allow numbers with up to 2 decimal places
    const value = e.target.value;
    const regex = /^\d*\.?\d{0,2}$/;
    
    if (regex.test(value) || value === '') {
      setAmount(value);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {currentStep === 'pin-confirmation' ? (
        <PinConfirmation 
          onCancel={handlePinCancel}
          onConfirm={handlePinConfirm}
        />
      ) : (
        <>
          {/* Header */}
          <header className="flex items-center px-4 py-3 border-b">
            <button onClick={handleBack} className="text-gray-700">
              <ChevronLeft className="h-6 w-6" />
            </button>
            <h1 className="ml-4 text-lg font-medium text-gray-800">UPI Transfer</h1>
          </header>

          {/* Content */}
          <div className="flex-1 flex flex-col p-6">
            {currentStep === 'upi-input' ? (
              <>
                <h2 className="text-xl font-medium text-gray-800 mb-2">Enter UPI ID or number</h2>
                <p className="text-gray-500 text-sm mb-8">
                  Pay any <span className="font-semibold">UPI</span> app using UPI ID or number
                </p>

                {/* UPI Input Field */}
                <div className="mb-8">
                  <label className="text-xs text-gray-500 mb-1 block">UPI ID or number</label>
                  <Input
                    type="text" 
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    className="border-gray-300 text-lg py-6"
                    placeholder="Enter UPI ID or phone number"
                    autoFocus
                  />
                </div>
              </>
            ) : (
              <>
                <h2 className="text-xl font-medium text-gray-800 mb-2">Enter Amount</h2>
                <p className="text-gray-500 text-sm mb-6">
                  How much would you like to send to <span className="font-semibold">{upiId}</span>?
                </p>

                {/* Amount Input Field */}
                <div className="mb-8">
                  <div className="flex items-center bg-seva-cream rounded-lg p-4 mb-6">
                    <div className="flex-1">
                      <p className="text-sm text-gray-500 mb-1">Amount</p>
                      <div className="flex items-center">
                        <span className="text-gray-700 mr-2 text-xl">₹</span>
                        <Input
                          type="text"
                          inputMode="decimal"
                          value={amount}
                          onChange={handleAmountChange}
                          className="border-none bg-transparent text-3xl font-bold text-gray-800 p-0 focus-visible:ring-0 h-auto"
                          placeholder="0.00"
                          autoFocus
                        />
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 text-center">
                    Transfer fee: <span className="font-semibold">Free</span>
                  </p>
                </div>
              </>
            )}

            {/* Continue Button */}
            <Button
              onClick={handleContinue}
              disabled={currentStep === 'upi-input' ? !upiId.trim() : !amount.trim()}
              className="w-full bg-seva-green hover:bg-green-600 text-white py-6 rounded-md text-lg mt-auto"
            >
              Continue
            </Button>
          </div>
        </>
      )}
    </div>
  );
};

export default UpiTransfer;
