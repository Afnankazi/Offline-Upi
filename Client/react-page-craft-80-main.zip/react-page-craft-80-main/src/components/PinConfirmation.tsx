
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EyeOff, Eye, ChevronLeft } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

interface PinConfirmationProps {
  onCancel: () => void;
  onConfirm: () => void;
}

const PinConfirmation = ({ onCancel, onConfirm }: PinConfirmationProps) => {
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const { toast } = useToast();

  const handleConfirm = () => {
    const storedPin = localStorage.getItem('userPin');
    
    if (storedPin && pin === storedPin) {
      onConfirm();
    } else {
      toast({
        title: "Incorrect PIN",
        description: "Please enter the correct PIN to continue",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-white flex flex-col z-50">
      {/* Header */}
      <div className="p-4 border-b">
        <button onClick={onCancel} className="p-1">
          <ChevronLeft className="h-6 w-6" />
        </button>
      </div>

      {/* Pin Entry Form */}
      <div className="flex-1 flex flex-col justify-start p-6">
        <h1 className="text-xl font-medium text-gray-800 mb-2">Confirm PIN</h1>
        <p className="text-gray-500 text-sm mb-8">
          Please input your PIN before continuing payment
        </p>

        <div className="relative mb-8">
          <Input
            type={showPin ? "text" : "password"}
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="Enter 6-digit PIN"
            maxLength={6}
            inputMode="numeric"
            pattern="[0-9]*"
            className="pr-10 text-lg"
            autoFocus
          />
          <button
            type="button"
            onClick={() => setShowPin(!showPin)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2"
          >
            {showPin ? <EyeOff className="h-5 w-5 text-gray-400" /> : <Eye className="h-5 w-5 text-gray-400" />}
          </button>
          <p className="text-xs text-gray-500 mt-1">Must be exactly 6 digits</p>
        </div>

        {/* Confirm Button */}
        <Button
          type="button"
          className="w-full bg-green-500 hover:bg-green-600 text-white py-6 rounded-md text-lg"
          onClick={handleConfirm}
          disabled={pin.length !== 6}
        >
          Confirm PIN
        </Button>
      </div>
    </div>
  );
};

export default PinConfirmation;
